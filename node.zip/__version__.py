"""
ComfyUI-SiberiaNodes - Version information

Author: siberiah0h
Email: siberiah0h@gmail.com
Technical Blog: www.dataeast.cn
Last Updated: 2025-11-15
"""

__version__ = "1.0.0"
__title__ = "ComfyUI-SiberiaNodes"
__description__ = "Custom nodes for ComfyUI with Ollama integration"
__author__ = "siberiah0h"
__email__ = "siberiah0h@gmail.com"
__license__ = "MIT"